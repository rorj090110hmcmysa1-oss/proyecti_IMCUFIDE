from django.shortcuts import render, redirect
from django.http import JsonResponse

# ESTE APARTADO DE FUNCIONES ES PARA CREAR, ELIMINAR MOSTRAR Y ACTUALIZAR LAS ESTADISTICAS 
from django.shortcuts import render, redirect, get_object_or_404
from .models import estadisticas, equipo, deporte, categoria, rama


#CREAR ESTADISTICAS

def crear_estadistica(request):
    deportes = deporte.objects.all()

    
    equipo_id = request.GET.get("equipo")
    equipo_obj = None
    if equipo_id:
        try:
            equipo_obj = equipo.objects.get(id=equipo_id)
        except equipo.DoesNotExist:
            equipo_obj = None


    if request.method == "POST":
        nombre_equipo = request.POST.get("nombre_equipo")
        id_deporte = request.POST.get("deporte")
        id_categoria = request.POST.get("categoria")
        nombre_rama = request.POST.get("rama")

        if not nombre_equipo or not id_deporte or not id_categoria or not nombre_rama:
            return render(request, "Resultados/crear_equipo.html", {
                "deportes": deportes,
                "error": "Todos los campos son obligatorios."
            })

        # Obtener objetos de deporte y categoría
        deporte_obj = deporte.objects.get(iddeporte=id_deporte)
        categoria_obj = categoria.objects.get(id=id_categoria, dep=deporte_obj)

        # Crear o obtener la rama
        rama_obj, created = rama.objects.get_or_create(
            nombrerama=nombre_rama,
            pertenencia=categoria_obj
        )

        # Crear el equipo
        equipo_obj, created = equipo.objects.get_or_create(
            nombreequipo=nombre_equipo,
            defaults={"pertenenciarama": rama_obj}
        )
        

        # 👇 CREAR ESTADÍSTICAS SI NO EXISTEN
        estadisticas.objects.get_or_create(
            equipo=equipo_obj,
            defaults={
                "jj": 0,
                "jg": 0,
                "jp": 0,
                "puntos": 0,
                "gaf": 0,
                "gc": 0,
                "dif": 0,
                "amonestaciones": 0,
            }
        )

        return redirect("tabla_posiciones")  # Cambia según tu URL

    return render(request, "crear_estadistica.html", {
        "deportes": deportes,
        "equipo_preseleccionado": equipo_obj,
    })


def categorias_por_deporte(request, deporte_id):
    categorias = categoria.objects.filter(dep_id=deporte_id)
    data = [{"id": c.id, "nombrecategoria": c.nombrecategoria} for c in categorias]
    return JsonResponse(data, safe=False)

def ramas_por_categoria(request, categoria_id):
    ramas = rama.objects.filter(pertenencia_id=categoria_id)
    data = [{"id": r.id, "nombrerama": r.nombrerama} for r in ramas]
    return JsonResponse(data, safe=False)



#EDUTAR ESTADISTICAS
def editar_estadistica(request, id):
     # 1️⃣ Buscar la estadística por su ID
    estadistica = get_object_or_404(estadisticas, id=id)

    # 2️⃣ Obtener el equipo relacionado
    equipo_obj = estadistica.equipo


    estadistica, created = estadisticas.objects.get_or_create(
        equipo=equipo_obj,
        defaults={
            "jj": 0,
            "jg": 0,
            "jp": 0,
            "puntos": 0,
            "gaf": 0,
            "gc": 0,
            "dif": 0,
            "amonestaciones": 0,
        }
    )

    if request.method == "POST":
        estadistica.jj = request.POST["jj"]
        estadistica.jg = request.POST["jg"]
        estadistica.jp = request.POST["jp"]
        estadistica.puntos = request.POST["puntos"]
        estadistica.gaf = request.POST["gaf"]
        estadistica.gc = request.POST["gc"]
        estadistica.dif = request.POST["dif"]
        estadistica.amonestaciones = request.POST["amon"]
        estadistica.save()

        return redirect("tabla_posiciones")

    return render(request, "editar_estadistica.html", {
        "dato": estadistica,
        "equipos": equipo.objects.all()
    })


def eliminar_estadistica(request, id):
    equipo_obj = get_object_or_404(equipo, id=id)
    equipo_obj.delete()  # 🔥 elimina equipo + estadísticas
    return redirect("tabla_posiciones")


def tabla_posiciones(request):
    equipos = equipo.objects.select_related(
        "pertenenciarama__pertenencia__dep"
    ).all()

    tabla = []

    for e in equipos:
        est = estadisticas.objects.filter(equipo=e).first()

        tabla.append({
            "id": est.id if est else None,
            "equipo": e,
            "jj": est.jj if est else 0,
            "jg": est.jg if est else 0,
            "jp": est.jp if est else 0,
            "puntos": est.puntos if est else 0,
            "gaf": est.gaf if est else 0,
            "gc": est.gc if est else 0,
            "dif": est.dif if est else 0,
            "amonestaciones": est.amonestaciones if est else 0,
        })

    # Ordenar tabla
    tabla = sorted(tabla, key=lambda x: (x["puntos"], x["dif"]), reverse=True)

    return render(request, "Tabla.html", {"tabla": tabla})




from django.shortcuts import render
from django_tables2 import SingleTableView

def inicio(request):
    return render(request,'Inicio.html')

from .models import estadisticas
from .tables import estadisticas2

class PersonListView(SingleTableView):
    model = estadisticas
    table_class = estadisticas2
    template_name = 'Tabla.html'

from django.views.generic import ListView
from .models import estadisticas

class PersonListView(ListView):
    model = estadisticas
    template_name = "Tabla.html"  # aquí le dices a Django tu HTML
    context_object_name = "tabla"  # el nombre que usarás en tu template
