# tutorial/tables.py
import django_tables2 as tables
from .models import estadisticas
from django_tables2.export.views import ExportMixin
from django_filters import FilterSet

class estadisticas2(tables.Table, ExportMixin):
    export_formats = ['csv']

    acciones = tables.TemplateColumn(
            template_code="""
            <a href="{% url 'editar_estadistica' record.id %}">
                <button>Editar</button>
            </a>
            <a href="{% url 'eliminar_estadistica' record.id %}">
                <button>Eliminar</button>
            </a>
            """,
            verbose_name="Acciones",
            orderable=False
        )
    

    class Meta:
        model = estadisticas
        fields = (
            "equipos",
            "jg",
            "jp",
            "puntos",
            "gaf",
            "gc",
            "dif",
            "faltas",
        )
        attrs = {"class": "mytable"}
        order_by = ("-puntos",)

    # class Meta:
    #     model = estadisticas
    #     fields = ("equipos","jg","jp","puntos","gaf","gc","dif","faltas","acciones" )
    #     attrs = {"class": "mytable"}
    #     order_by = ("-puntos",)

