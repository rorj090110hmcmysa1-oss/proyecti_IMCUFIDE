from django.shortcuts import render

from django.shortcuts import render
from django_tables2 import SingleTableView
from django_tables2.export.views import ExportMixin
from .models import equipo

def inicio(request):
    return render(request,'Inicio.html')

from .models import estadisticas
from .tables import estadisticas2

class PersonListView(SingleTableView, ExportMixin):
    model = estadisticas
    table_class = estadisticas2
    template_name = 'Tabla.html'

from django.shortcuts import render

from django.shortcuts import render
from django_tables2 import SingleTableView
from django_tables2.export.views import ExportMixin
from django_tables2.export.export import TableExport
from django_tables2 import RequestConfig



def inicio(request):
    return render(request,'Inicio.html')

import django_tables2 as tables
from .models import estadisticas

class PersonListView(SingleTableView, ExportMixin):
    model = estadisticas
    table_class = estadisticas2
    template_name = 'Tabla.html'
    export_formats = ['csv']

class estadisticas2(tables.Table):
    equipos = tables.Column(accessor='equipos.nombreequipo', verbose_name='Equipo')

    class Meta:
        model = estadisticas
        template_name = "django_tables2/bootstrap.html"  # o tu template
        fields = ("equipos", "jj", "jg", "jp", "puntos", "gaf", "gc", "dif", "faltas")
        order_by = ("puntos", "-dif")  # Ejemplo de orden por puntos y diferencia
        attrs = {"class": "mytable"}
# # Actualizar un productos
# def update_product(request):
#     if request.method == "GET":

#         # El usuario todavía no ha buscado nada
#         if "kword" not in request.GET:
#             return render(request, "update_product.html")

#         # Buscar producto por nombre
#         nombre = request.GET.get("kword", "")

#         try:
#             product = products.objects.get(title=nombre)
#         except products.DoesNotExist:
#             return render(request, "update_product.html", {
#                 "error": "No existe un producto con ese nombre."
#             })

#         # Si encuentra el producto, mostrar el form con datos
#         form = newproductform(initial={
#             "title": product.title,
#             "price": product.price,
#             "store": product.store.name
#         })

#         return render(request, "update_product.html", {
#             "forms": form,
#             "product": product
#         })

#     else:
#         # Actualizar el producto
#         nombre_original = request.POST.get("title_original")
#         product = products.objects.get(title=nombre_original)

#         form = newproductform(request.POST)
#         if form.is_valid():
#             store_obj = stores.objects.get(name=form.cleaned_data["store"])

#             product.title = form.cleaned_data["title"]
#             product.price = form.cleaned_data["price"]
#             product.store = store_obj
#             product.save()

#             return redirect("products")

#         return render(request, "update_product.html", {
#             "forms": form,
#             "error": "Datos inválidos"
#         })
from django.shortcuts import render
from .models import estadisticas
from .tables import estadisticas2



def equipos_eliminar(request):
    if request.method == 'POST':
        equipo_id = request.POST.get('equipo_id')
        equipo = get_object_or_404(equipo, id=equipo_id)
        equipo.delete()
        mensaje = f"Equipo '{equipo.equipos}' eliminado correctamente."
    else:
        mensaje = ""

    equipos = equipo.objects.all()
    return render(request, 'equipos_eliminar.html', {'equipos': equipos, 'mensaje': mensaje})


def delete_equipo2(request):
    # Obtenemos todos los equipos
    equipos = equipo.objects.all()
    mensaje = None
    error = None

    if request.method == "POST":
        # Obtenemos el ID del equipo que se quiere eliminar
        equipo_id = request.POST.get("equipo_id")
        if equipo_id:
            try:
                equipo_obj = equipo.objects.get(id=equipo_id)
                equipo_obj.delete()
                mensaje = f"El equipo '{equipo_obj.equipos}' se eliminó correctamente."
                # Refrescamos la lista
                equipos = equipo.objects.all()
            except equipo.DoesNotExist:
                error = "No se encontró el equipo a eliminar."

    return render(request, "eliminar_equipo.html", {
        "equipos": equipos,
        "mensaje": mensaje,
        "error": error
    })